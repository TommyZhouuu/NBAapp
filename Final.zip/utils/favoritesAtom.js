// utils/favoritesAtom.js
import { atom } from 'jotai';

export const favoritesAtom = atom([]);  
