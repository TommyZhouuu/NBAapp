// utils/searchAtom.js
import { atom } from 'jotai';

export const searchHistoryAtom = atom([]);  // Holds list of recent search queries (initially empty)
