(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_favorites_page_4ed2a383.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_favorites_page_4ed2a383.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f3c44047._.js",
    "static/chunks/node_modules_next_dist_compiled_crypto-browserify_index_07270ec0.js",
    "static/chunks/node_modules_next_dist_compiled_da909a55._.js",
    "static/chunks/node_modules_next_dist_f94546ba._.js",
    "static/chunks/node_modules_fdf8fb32._.js",
    "static/chunks/_e2a01167._.js"
  ],
  "source": "dynamic"
});
