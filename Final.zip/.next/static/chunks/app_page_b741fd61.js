(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_b741fd61.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_b741fd61.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_613e1545._.js",
    "static/chunks/node_modules_next_dist_compiled_crypto-browserify_index_07270ec0.js",
    "static/chunks/node_modules_next_dist_compiled_acd2ed78._.js",
    "static/chunks/node_modules_next_dist_da8a1bb5._.js",
    "static/chunks/node_modules_next_599b5139._.js",
    "static/chunks/node_modules_fdf8fb32._.js",
    "static/chunks/_03a8182a._.js"
  ],
  "source": "dynamic"
});
